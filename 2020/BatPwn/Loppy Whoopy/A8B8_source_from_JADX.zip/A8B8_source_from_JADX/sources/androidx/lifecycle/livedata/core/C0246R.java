package androidx.lifecycle.livedata.core;

/* renamed from: androidx.lifecycle.livedata.core.R */
public final class C0246R {
    private C0246R() {
    }
}
