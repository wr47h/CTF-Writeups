package androidx.arch.core;

/* renamed from: androidx.arch.core.R */
public final class C0007R {
    private C0007R() {
    }
}
