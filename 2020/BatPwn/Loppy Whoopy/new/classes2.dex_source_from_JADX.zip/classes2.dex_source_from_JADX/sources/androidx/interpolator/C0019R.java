package androidx.interpolator;

/* renamed from: androidx.interpolator.R */
public final class C0019R {
    private C0019R() {
    }
}
