package androidx.lifecycle.livedata;

/* renamed from: androidx.lifecycle.livedata.R */
public final class C0021R {
    private C0021R() {
    }
}
