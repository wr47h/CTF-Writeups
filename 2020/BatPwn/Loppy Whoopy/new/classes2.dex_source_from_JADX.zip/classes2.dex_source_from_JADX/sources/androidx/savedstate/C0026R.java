package androidx.savedstate;

/* renamed from: androidx.savedstate.R */
public final class C0026R {
    private C0026R() {
    }
}
