package androidx.lifecycle;

/* renamed from: androidx.lifecycle.R */
public final class C0020R {
    private C0020R() {
    }
}
