package androidx.cursoradapter;

/* renamed from: androidx.cursoradapter.R */
public final class C0012R {
    private C0012R() {
    }
}
