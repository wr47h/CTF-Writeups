package androidx.lifecycle.viewmodel;

/* renamed from: androidx.lifecycle.viewmodel.R */
public final class C0023R {
    private C0023R() {
    }
}
