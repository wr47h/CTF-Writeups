package androidx.lifecycle.livedata.core;

/* renamed from: androidx.lifecycle.livedata.core.R */
public final class C0022R {
    private C0022R() {
    }
}
